package com.example.moviedatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Search extends AppCompatActivity implements ListViewAdapter.onItemClickListener {
    ListView listView;
    private List<MovieItem> movieItemList;
    private String query;
    private String KEY_QUERY = "TONY STARK";

    private JsonPlaceHolderApi jsonPlaceHolderApi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        listView = findViewById(R.id.listView);
        movieItemList = new ArrayList<>();

        Bundle getData = getIntent().getExtras();
        query = getData.getString("KEY_QUERY");

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://rest.farzain.com/api/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        jsonPlaceHolderApi = retrofit.create(JsonPlaceHolderApi.class);
        getPost();
//        getComment();
    }

    private void getPost() {

        Call<Post> call = jsonPlaceHolderApi.getPost("4lo4dq17U3yFlNIXUZpph2HGP",query);

        call.enqueue(new Callback<Post>() {
            @Override
            public void onResponse(Call<Post> call, Response<Post> response) {
//                if(!response.isSuccessful()) {
//                    textViewResult.setText("Code :" + response.code());
//                    return;
//                }

                Post result = response.body();
                Info info = result.getInfo();
                Count count = result.getCount();

                    MovieItem movieItem = new MovieItem(

                            "Full Name : " + info.getFullName(),
                            "Bio : " + info.getBio(),
                            "Followers : " + count.getFollowers().toString(),
                            "Following : " + count.getFollowing().toString(),
                            info.getProfilePict());

                    movieItemList.add(movieItem);


                ListViewAdapter adapter = new ListViewAdapter(Search.this,movieItemList, getApplicationContext());
                listView.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<Post> call, Throwable t) {
//                textViewResult.setText(t.getMessage());
            }
        });
    }

    @Override
    public void onItemClick(int position) {

        MovieItem item = movieItemList.get(position);

        Uri uri = Uri.parse("http://instagram.com/_u/krnwnrukito");
        Intent likeIng = new Intent(Intent.ACTION_VIEW, uri);

        likeIng.setPackage("com.instagram.android");

        try {
            startActivity(likeIng);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://instagram.com/krnwnrukito")));
        }
    }
}