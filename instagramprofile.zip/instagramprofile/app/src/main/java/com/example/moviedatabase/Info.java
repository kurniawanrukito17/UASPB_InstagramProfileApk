package com.example.moviedatabase;

import com.google.gson.annotations.SerializedName;

public class Info {

    @SerializedName("profile_pict")
    private String profilePict;
    @SerializedName("bio")
    private String bio;
    @SerializedName("url_bio")
    private Object urlBio;
    @SerializedName("full_name")
    private String fullName;
    @SerializedName("username")
    private String username;

    public String getProfilePict() {
        return profilePict;
    }

    public void setProfilePict(String profilePict) {
        this.profilePict = profilePict;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public Object getUrlBio() {
        return urlBio;
    }

    public void setUrlBio(Object urlBio) {
        this.urlBio = urlBio;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

}
