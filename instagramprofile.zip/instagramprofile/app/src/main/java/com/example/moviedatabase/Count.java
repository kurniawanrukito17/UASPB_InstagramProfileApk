package com.example.moviedatabase;

import com.google.gson.annotations.SerializedName;

public class Count {

    @SerializedName("followers")
    private Integer followers;
    @SerializedName("following")
    private Integer following;
    @SerializedName("post")
    private Integer post;

    public Integer getFollowers() {
        return followers;
    }

    public void setFollowers(Integer followers) {
        this.followers = followers;
    }

    public Integer getFollowing() {
        return following;
    }

    public void setFollowing(Integer following) {
        this.following = following;
    }

    public Integer getPost() {
        return post;
    }

    public void setPost(Integer post) {
        this.post = post;
    }

}
