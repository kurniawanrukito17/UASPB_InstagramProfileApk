package com.example.moviedatabase;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Post {

    @SerializedName("status")
    private String status;
    @SerializedName("info")
    private Info info;
    @SerializedName("count")
    private Count count;
    @SerializedName("creator")
    private String creator;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Info getInfo() {
        return info;
    }

    public void setInfo(Info info) {
        this.info = info;
    }

    public Count getCount() {
        return count;
    }

    public void setCount(Count count) {
        this.count = count;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }
}
